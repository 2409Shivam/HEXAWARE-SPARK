class InsufficientFundsException(Exception):
    pass


class InvalidAccountException(Exception):
    pass


class OverDraftLimitExceededException(Exception):
    pass
